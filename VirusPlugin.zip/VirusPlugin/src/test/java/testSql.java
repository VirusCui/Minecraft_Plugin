import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class testSql {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        BaseDao dao = new BaseDao();
        Scanner input = new Scanner(System.in);
        String sql = "";
        String pName = "";
        String UUID = "";
        Date date = null;
        System.out.println("输入UUID");
        UUID = input.next();
        System.out.println("输入玩家名称");
        pName = input.next();
        System.out.println("输入时间");
        date = Date.valueOf(input.next());


        sql = "select * from playerlastleave where UUID = ?";
        Object[] obj = {UUID};
        dao.Query(sql,obj);
        ResultSet rs = dao.rs;
        if(rs.next()){
            sql = "update playerlastleave set Date = ? where UUID = ?";
            Object[] objUpdate = {date,UUID};
            dao.dml(sql,objUpdate);
            System.out.println("更改成功");
        }else {
            sql = "insert into playerlastleave(pName,UUID,Date) Values(?,?,?)";
            Object[] objInsert = {pName,UUID,date};
            dao.dml(sql,objInsert);
            System.out.println("添加成功");


        }
    }
}
