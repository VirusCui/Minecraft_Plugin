package com.virus;

import com.virus.Listener.*;
import com.virus.SQL.teleportImpl;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import java.util.UUID;

public final class Main extends JavaPlugin {

    public static Main instance;

    public static Plugin getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        // Plugin startup logic
        instance = this;
        // Plugin startup logic
        getLogger().info(ChatColor.GREEN+"+++++++++++++++++++++");
        getLogger().info(ChatColor.GREEN+"|    加载成功       |");
        getLogger().info(ChatColor.GREEN+"|    作者：Virus_Cui|");
        getLogger().info(ChatColor.GREEN+"|    版本：1.1.3    |");
        getLogger().info(ChatColor.GREEN+"|   QQ:2437916756   |");
        getLogger().info(ChatColor.GREEN+"+++++++++++++++++++++");
        getServer().getPluginManager().registerEvents(new PlayerKillListener(), this);
        getServer().getPluginManager().registerEvents(new gameMode(),this);
        getServer().getPluginManager().registerEvents(new Left(),this);
        getServer().getPluginManager().registerEvents(new PlayerInfo(),this);
        getServer().getPluginManager().registerEvents(new PlayerJoin(),this);
        getServer().getPluginManager().registerEvents(new WorldWeather(),this);

    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(command.getName().equalsIgnoreCase("show")){
            try {
                Player p = (Player) sender;
                String PlayerName = p.getName();
                int lv = p.getLevel();
                UUID UUID = p.getUniqueId();
                //ShowPlayer
                sender.sendMessage(ChatColor.GREEN+"[<==============[ShowPlayerInfo]==============>]");
                sender.sendMessage(ChatColor.GREEN+"|名称: "+PlayerName);
                sender.sendMessage(ChatColor.GREEN+"|等级: "+lv);
                sender.sendMessage(ChatColor.GREEN+"|UUID: "+UUID);
                sender.sendMessage(ChatColor.GREEN+"[<==========================================>]");
                //getLogger
                getLogger().info(ChatColor.GREEN+"[===============[ShowPlayerInfo]===============]");
                getLogger().info(ChatColor.GREEN+"|名称: "+PlayerName);
                getLogger().info(ChatColor.GREEN+"|等级: "+lv);
                getLogger().info(ChatColor.GREEN+"|UUID: "+UUID);
                getLogger().info(ChatColor.GREEN+"[============================================]");
            }catch (Exception e){
                getLogger().info("此命令只能由玩家使用");
            }

        }
        if(command.getName().equalsIgnoreCase("ClearChat")){
            try{
                Player player = (Player) sender;
                for (int i = 0;i<20;i++){
                    sender.sendMessage("\n");
                }
            }catch (Exception e){
                getLogger().info("此命令只能由玩家使用");
            }
        }
        if(command.getName().equalsIgnoreCase("bk")){
            Player p = (Player) sender;
            teleportImpl impl = new teleportImpl();
            try {
                impl.tel(p);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                getLogger().info("此命令只能由玩家使用");
            }
        }
        return true;
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
